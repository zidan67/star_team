import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class SignIn extends JFrame implements ActionListener {
	private static JPanel backPanel, forePanel;
	private static JLabel mainLabel2, nameLabel, passwordLabel, singUpLabel, imagelabel;
	private static JTextField nameTextField;
	private static JPasswordField passPasswordField;
	private static JButton signInButton,singUpButton,forgetButton;
	
	private static String username,password;
	ImageIcon img;
	
	public SignIn(){
		//frame
		this.setTitle("Car Rental Portal");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1200,600);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
		
		//backPanel
		backPanel=new JPanel();
        backPanel.setLayout(null);
		backPanel.setBackground(Color.white);
		
		//forePanel
		forePanel = new JPanel();
        forePanel.setLayout(null);
		
		forePanel.setBackground(Color.white);
		
		//labels
		
		img = new ImageIcon(getClass().getResource("/bin/images/banner-image.jpg"));
		
		imagelabel = new JLabel(img);
		imagelabel.setBounds(0,0,1200,600);
		backPanel.add(imagelabel);
		
		mainLabel2 =new JLabel("FIND THE RIGHT CAR FOR YOU.");
	    mainLabel2.setForeground(Color.WHITE);
		mainLabel2.setBounds(650,65,900,35);
        mainLabel2.setFont(new Font("Arial", Font.BOLD, 32));
		
		imagelabel.add(mainLabel2);
		
		
		
		
		nameLabel =new JLabel("User Name");
		nameLabel.setForeground(Color.WHITE);
		nameLabel.setBounds(810,190,160,30);
		nameLabel.setFont(new Font("Arial", Font.BOLD, 22));
		imagelabel.add(nameLabel);
		
		passwordLabel =new JLabel("Password");
		passwordLabel.setForeground(Color.WHITE);
		passwordLabel.setBounds(810,250,160,30);
		passwordLabel.setFont(new Font("Arial", Font.BOLD, 22));
		imagelabel.add(passwordLabel);
		
		singUpLabel=new JLabel("Dont have an account? ");
		singUpLabel.setForeground(Color.WHITE);
		singUpLabel.setBounds(870,360,250,30);
		singUpLabel.setFont(new Font("Arial", Font.BOLD, 16));
		imagelabel.add(singUpLabel);
		
		//fields
		nameTextField=new JTextField(25);
		nameTextField.setBounds(950,190,190,30);
		nameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
		imagelabel.add(nameTextField);
		
		passPasswordField=new JPasswordField(30);
		passPasswordField.setBounds(950,250,190,30);
		passPasswordField.setFont(new Font("Arial", Font.PLAIN, 20));
		imagelabel.add(passPasswordField);
		
		//button
		signInButton=new JButton("Sign In");
		signInButton.setBounds(950,320,90,30);		
		signInButton.setFont(new Font("Arial", Font.PLAIN, 16));
        signInButton.addActionListener(this);
		imagelabel.add(signInButton);
		
		singUpButton=new JButton("<HTML><U><B>Sign Up</B></U></HTML>");
		singUpButton.setBounds(1030,360,95,30);	
		singUpButton.setFont(new Font("Arial", Font.BOLD, 16));
		singUpButton.setForeground(new Color(255,255,255));
		singUpButton.setBackground(new Color(10,10,255));
		singUpButton.setOpaque(false);
		singUpButton.setBorderPainted(false);
        singUpButton.addActionListener(this);
		imagelabel.add(singUpButton);
			
		backPanel.add(forePanel);
		this.add(backPanel);
		this.setVisible(true);
	}
	
	public static void main(String[] args){
		new SignIn();
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==signInButton){
			username=nameTextField.getText();
			password=passPasswordField.getText();
			CreateAccount createAccount = new CreateAccount();
		
			if(createAccount.getAccount(username, password)){
				JOptionPane.showMessageDialog(null,"Login Successful");
				
				SelectCar1 f=new SelectCar1();	
				this.setVisible(false);
            }
			else{
				JOptionPane.showMessageDialog(null, "Please insert UserName/Password correctly");
			}
		}
		else if(e.getSource()==singUpButton){
			SignUp f=new SignUp();
			this.setVisible(false);
		}
    }
	
}