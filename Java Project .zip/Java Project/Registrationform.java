import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

	public class Registrationform implements ActionListener{	
	   
	    private static JFrame frame;
		public static JTextField username,number,mail,nid,CBD,CRD;
	    private static JLabel label,label1,label2,label3,label4,label5;
	    private static JButton b1,b2;
	    private static JPanel panel,panel1;
	   
	public Registrationform(){
	          
		frame=new JFrame();
		frame.setTitle("Car Rental System"); 
		frame.setSize(800,600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setLayout(null);
        frame.setLocationRelativeTo(null);


		panel =new JPanel();
		panel.setBounds(0,0,800,600);
		panel.setBackground(Color.white);
		panel.setLayout(null);

		panel1 =new JPanel();
		panel1.setBounds(30,30,700,500);
		panel1.setBackground(Color.decode("#A2A1A1"));
		panel1.setLayout(null);
		
		
		label5=new JLabel();
		label5.setText("Car Registration Form");     
		label5.setBounds(240,60,400,35);
		label5.setFont(new Font("Arial",Font.BOLD,20));
		panel.add(label5);
				
				
		label=new JLabel();
		label.setText("Full Name");     
		label.setBounds(140,140,110,35);
		label.setFont(new Font("Arial",Font.BOLD,20));
		panel.add(label);
				
	    username=new JTextField();
		username.setBounds(300,140,250,30);
		panel.add(username);
				
		label1=new JLabel();
		label1.setText("Phone number");
		label1.setBounds(140,110,200,170);
		label1.setFont(new Font("Arial",Font.BOLD,20));
		panel.add(label1);
				
        number=new JTextField();
		number.setBounds(300,185,250,30);
		
		panel.add(number);
				
		label2=new JLabel();
		label2.setText("Email Adress");     
	    label2.setBounds(140,90,200,305);
		label2.setFont(new Font("Arial",Font.BOLD,20));
		panel.add(label2);
				
		mail=new JTextField();
		mail.setBounds(300,230,250,30);
		panel.add(mail);
				
		label3=new JLabel();
		label3.setText("NID");     
		label3.setBounds(140,70,200,460);
		label3.setFont(new Font("Arial",Font.BOLD,20));
		panel.add(label3);
				
		nid=new JTextField();
		nid.setBounds(300,280,250,30);
		panel.add(nid);
				
		label3=new JLabel();
		label3.setText("Booking Date");     
		label3.setBounds(140,40,175,615);
		label3.setFont(new Font("Arial",Font.BOLD,20));
		panel.add(label3);
				
		CBD=new JTextField();
		CBD.setBounds(300,330,250,30);
		panel.add(CBD);
				
		label4=new JLabel();
		label4.setText("Return Date");     
		label4.setBounds(140,30,200,730);
		label4.setFont(new Font("Arial",Font.BOLD,20));
		panel.add(label4);
				
		CRD=new JTextField();
		CRD.setBounds(300,380,250,30);
		panel.add(CRD);
				
		b1=new JButton();
		b1.setText("Proceed to Payment");
		b1.setBounds(400,440,300,40);
		b1.addActionListener(this);
		panel.add(b1);
				
		b2=new JButton();
		b2.setText("Back");
		b2.setBounds(100,440,90,40);
		b2.addActionListener(this);
		panel.add(b2);
			
		frame.add(panel);			   
		panel.add(panel1);		
		frame.setVisible(true);
	}
				
	public static void main(String[]args){
		new Registrationform();
	}
	public void actionPerformed(ActionEvent ae){
		if(ae.getSource()==b1){
			String fullName=new String(username.getText());
			String phoneNumber=new String(number.getText());
			String niddat=new String(nid.getText());
			String email=new String(mail.getText());
			String bookingDate=new String(CBD.getText());
			String returnDate=new String(CRD.getText());
			
			DataIO data=new DataIO(fullName, phoneNumber, email, niddat, bookingDate, returnDate);
			data.addData();
			
			form8 P= new form8();
			frame.setVisible(false);
			
		}
		 else if(ae.getSource()==b2){
			if(SelectCar1.choice==1){Car1 f=new Car1();}
			else if(SelectCar1.choice==2){Car2 f=new Car2();}
			else if(SelectCar1.choice==3){Car3 f=new Car3();}
			else if(SelectCar1.choice==4){Car4 f=new Car4();}
			else if(SelectCar1.choice==5){Car5 f=new Car5();}
			else if(SelectCar1.choice==6){Car6 f=new Car6();}			
			frame.setVisible(false);			
		}
		
	}
	}