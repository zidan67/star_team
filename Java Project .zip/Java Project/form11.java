//Rocket
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 
public class form11 extends JFrame implements ActionListener {
    JPanel p;
    JLabel l1, l2, l3, logoLabel; // Adding logoLabel
    JTextField t1;
    JPasswordField t2;
    JButton b2, b3;
 
    form11() {
        super(" Rocket ");
        this.setSize(800, 600);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 
        p = new JPanel();
        p.setSize(new Dimension(450, 300));
        p.setBackground(new Color(136,41,142));
        p.setLayout(null);
 
        // Adding Logo
        ImageIcon logoIcon = new ImageIcon("rocket.jpg"); // Assuming "rocket.jpg" is in the same directory
        Image scaledImage = logoIcon.getImage().getScaledInstance(175, 175, Image.SCALE_SMOOTH); // Adjusting image size
        ImageIcon scaledLogoIcon = new ImageIcon(scaledImage);
        logoLabel = new JLabel(scaledLogoIcon);
        logoLabel.setBounds(295, 25, 175, 175); // Adjusted size and position
        p.add(logoLabel);
 
        l1 = new JLabel();
        l1.setFont(new Font("Serif", Font.BOLD, 40));
        l1.setForeground(Color.BLUE);
        l1.setBounds(200, 170, 450, 50); // Adjusted position
        p.add(l1);
 
        l2 = new JLabel(" Mobile Number   :  ");
        l2.setFont(new Font("Serif", Font.BOLD, 25));
        l2.setForeground(Color.white);
        l2.setBounds(200, 275, 350, 30); // Adjusted position
        p.add(l2);
 
        t1 = new JTextField();
        t1.setBounds(410, 275, 180, 30); // Adjusted Y position
        p.add(t1);
 
        // Adjust Y position to place it below the "Mobile No" label with a two-line gap
        l3 = new JLabel(" Pin                         :  ");
        l3.setFont(new Font("Serif", Font.BOLD, 25));
        l3.setForeground(Color.white);
        l3.setBounds(200, 350, 350, 30); // Adjusted position
        p.add(l3);
 
        // Adjust Y position to place it below the "Pin" label
        t2 = new JPasswordField();
        t2.setBounds(410, 350, 180, 30); // Adjusted Y position
        p.add(t2);
 
        b2 = new JButton("Next");
        b2.setBounds(550, 500, 100, 30);
        b2.setBackground(Color.green);
        b2.addActionListener(this);
        p.add(b2);
 
        b3 = new JButton("Back");
        b3.setBounds(100, 500, 100, 30);
        b3.setBackground(Color.green);
        b3.addActionListener(this);
        p.add(b3);
 
        this.add(p);
    }
 
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b2) {
            String fullName = t1.getText();
            String userPassword = t2.getText();
 
            if (fullName.isEmpty() || userPassword.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill All Boxes");
            } else {
                JOptionPane.showMessageDialog(null, "Payment Successful");
                t1.setText("");
                t2.setText("");
 
               YourCar f = new YourCar();
				this.setVisible(false);
				f.setVisible(true);
            }
        } else if (ae.getSource() == b3) {
            form8 f = new form8();
            this.setVisible(false);
            f.setVisible(true);
        }
    }
 
    
}