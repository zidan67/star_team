import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class SignUp extends JFrame implements ActionListener {
	private static JPanel backPanel, forePanel;
	private static JLabel imagelabel, mainLabel, fnameLabel, unameLabel, passwordLabel, emailLabel;
	private static JTextField fnameTextField, unameTextField, emailTextField;
	private static JPasswordField passPasswordField;
	private static JButton backButton, signInButton;
	private static ImageIcon img;
	private static String username,password,email,fullname;
	
	public SignUp(){
		//frame
		this.setTitle("Sign Up");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800, 600);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
		
		//backPanel
		backPanel=new JPanel();
        backPanel.setLayout(null);
		backPanel.setBackground(Color.white);
		
		//forePanel
		forePanel = new JPanel();
        forePanel.setLayout(null);
		forePanel.setBounds(5,75,500,500);
		forePanel.setBackground(Color.white);
		
		//labels	
		fnameLabel =new JLabel("Full Name");
		fnameLabel.setBounds(45,80,160,30);
		fnameLabel.setFont(new Font("Arial", Font.BOLD, 18));
		forePanel.add(fnameLabel);
		
		unameLabel =new JLabel("Username");
		unameLabel.setBounds(45,130,160,30);
		unameLabel.setFont(new Font("Arial", Font.BOLD, 18));
		forePanel.add(unameLabel);
		
		emailLabel =new JLabel("Email");
		emailLabel.setBounds(45,180,160,30);
		emailLabel.setFont(new Font("Arial", Font.BOLD, 18));
		forePanel.add(emailLabel);
		
		passwordLabel =new JLabel("Password");
		passwordLabel.setBounds(45,230,160,22);
		passwordLabel.setFont(new Font("Arial", Font.BOLD, 18));
		forePanel.add(passwordLabel);
		
		//background
		img = new ImageIcon(getClass().getResource("/bin/images/car3.jpg"));
		imagelabel = new JLabel(img);
		imagelabel.setBounds(400,0,400,500);
		backPanel.add(imagelabel);
		
		//fields
		fnameTextField=new JTextField(25);
		fnameTextField.setBounds(180,80,190,25);
		fnameTextField.setFont(new Font("Arial", Font.PLAIN, 14));
		forePanel.add(fnameTextField);
		
		unameTextField=new JTextField(25);
		unameTextField.setBounds(180,130,190,25);
		unameTextField.setFont(new Font("Arial", Font.PLAIN, 14));
		forePanel.add(unameTextField);
		
		emailTextField=new JTextField(25);
		emailTextField.setBounds(180,180,190,25);
		emailTextField.setFont(new Font("Arial", Font.PLAIN, 14));
		forePanel.add(emailTextField);
		
		passPasswordField=new JPasswordField(30);
		passPasswordField.setBounds(180,230,190,25);
		passPasswordField.setFont(new Font("Arial", Font.PLAIN,14));
		forePanel.add(passPasswordField);
		
		//button
		signInButton=new JButton("Sign Up");
		signInButton.setBounds(230,350,90,30);		
		signInButton.setFont(new Font("Arial", Font.PLAIN, 16));
        signInButton.addActionListener(this);
		forePanel.add(signInButton);
		
		backButton=new JButton("Back");
		backButton.setBounds(100,350,90,30);		
		backButton.setFont(new Font("Arial", Font.PLAIN, 16));
        backButton.addActionListener(this);
		forePanel.add(backButton);
		
		backPanel.add(forePanel);
		this.add(backPanel);
		this.setVisible(true);
	}
	
	public static void main(String[] args){
		new SignUp();
	}
	
	public void actionPerformed(ActionEvent e){
		
		if(e.getSource()==backButton){
			SignIn f=new SignIn();
		    this.setVisible(false);
		}
		else if(e.getSource()==signInButton){
			fullname=fnameTextField.getText();
		    email=emailTextField.getText();
		    username=unameTextField.getText();
		    password=passPasswordField.getText();
			if(fullname.isEmpty() || email.isEmpty() || username.isEmpty() || password.isEmpty()){	
				JOptionPane.showMessageDialog(null, "Please enter the fields correctly");
			}
			else{
				CreateAccount createAccount = new CreateAccount(fullname, email, username, password);
				createAccount.addAccount();
				JOptionPane.showMessageDialog(null, "Account Added");
				SignIn f=new SignIn();
				this.setVisible(false);
			}
		}
	}
}