import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class DataIO extends Data{
	
	//Empty Constructor
    public DataIO(){}
	
	//Para Constructor
	public DataIO(String fullName, String phoneNumber, String email, String nid, String bookingDate, String returnDate){
		super(fullName, phoneNumber, email, nid, bookingDate, returnDate);
	}
	
	public void setFullName(String fullName){this.fullName=fullName;}
	public void setPhoneNumber(String phoneNumber){this.phoneNumber=phoneNumber;}
	public void setEmail(String email){this.email=email;}
	public void setNid(String nid){this.nid=nid;}
	public void setBookingDate(String bookingDate){this.bookingDate=bookingDate;}
	public void setReturnDate(String returnDate){this.returnDate=returnDate;}
	
	public String getFullName(){return this.fullName;}
	public String getPhoneNumber(){return this.phoneNumber;}
	public String getEmail(){return this.email;}
	public String getNid(){return this.nid;}
	public String getBookingDate(){return this.bookingDate;}
	public String getReturnDate(){return this.returnDate;}
	
	public void addData(){
        try
        {
            file = new File("bin\\files\\Data.txt");
            file.createNewFile();
            writer  = new FileWriter(file,true);
            writer.write(getFullName()+"\t");
            writer.write(getPhoneNumber()+"\t");
            writer.write(getEmail()+"\t");
            writer.write(getNid()+"\t");
            writer.write(getBookingDate()+"\t");
            writer.write(getReturnDate()+"\n");
            writer.flush();
            writer.close();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }
	
	public String getFullNameIO(String userName){
		String IO=new String();
        boolean isAuth = false;
        String path ="bin\\files\\Data.txt";
        file = new File(path);
		try{
			sc = new Scanner(file);
			while(sc.hasNextLine()){
				String line = sc.nextLine();
				String[] value = line.split("\t");
				if(value[0].equals(userName)){
					isAuth=true;
					if(isAuth==true){
						IO=value[0];
					}
				}
			}
		}
		catch(IOException ioe){
			ioe.printStackTrace();
		}
		return IO;		
    }
	
	public String getPhoneNumberIO(String phoneNumber){
		String IO=new String();
        boolean isAuth = false;
        String path ="bin\\files\\Data.txt";
        file = new File(path);
		try{
			sc = new Scanner(file);
			while(sc.hasNextLine()){
				String line = sc.nextLine();
				String[] value = line.split("\t");
				if(value[1].equals(phoneNumber)){
					isAuth=true;
					if(isAuth==true){
						IO=value[1];
					}
				}
			}
		}
		catch(IOException ioe){
			ioe.printStackTrace();
		}
		return IO;		
    }
	
	public String getEmailIO(String email){
		String IO=new String();
        boolean isAuth = false;
        String path ="bin\\files\\Data.txt";
        file = new File(path);
		try{
			sc = new Scanner(file);
			while(sc.hasNextLine()){
				String line = sc.nextLine();
				String[] value = line.split("\t");
				if(value[2].equals(email)){
					isAuth=true;
					if(isAuth==true){
						IO=value[2];
					}
				}
			}
		}
		catch(IOException ioe){
			ioe.printStackTrace();
		}
		return IO;		
    }
	
	public String getNIDIO(String nid){
		String IO=new String();
        boolean isAuth = false;
        String path ="bin\\files\\Data.txt";
        file = new File(path);
		try{
			sc = new Scanner(file);
			while(sc.hasNextLine()){
				String line = sc.nextLine();
				String[] value = line.split("\t");
				if(value[3].equals(nid)){
					isAuth=true;
					if(isAuth==true){
						IO=value[3];
					}
				}
			}
		}
		catch(IOException ioe){
			ioe.printStackTrace();
		}
		return IO;		
    }
	
	public String getBookingDateIO(String bookingDate){
		String IO=new String();
        boolean isAuth = false;
        String path ="bin\\files\\Data.txt";
        file = new File(path);
		try{
			sc = new Scanner(file);
			while(sc.hasNextLine()){
				String line = sc.nextLine();
				String[] value = line.split("\t");
				if(value[4].equals(bookingDate)){
					isAuth=true;
					if(isAuth==true){
						IO=value[4];
					}
				}
			}
		}
		catch(IOException ioe){
			ioe.printStackTrace();
		}
		return IO;		
    }
	
	public String getReturnDateIO(String returnDate){
		String IO=new String();
        boolean isAuth = false;
        String path ="bin\\files\\Data.txt";
        file = new File(path);
		try{
			sc = new Scanner(file);
			while(sc.hasNextLine()){
				String line = sc.nextLine();
				String[] value = line.split("\t");
				if(value[5].equals(returnDate)){
					isAuth=true;
					if(isAuth==true){
						IO=value[5];
					}
				}
			}
		}
		catch(IOException ioe){
			ioe.printStackTrace();
		}
		return IO;		
    }
	
	public static void main(String[] agra){
		DataIO d=new DataIO();
		System.out.println(d.getFullNameIO("1"));
		System.out.println(d.getPhoneNumberIO("2"));
		System.out.println(d.getEmailIO("3"));
		System.out.println(d.getNIDIO("4"));
		System.out.println(d.getBookingDateIO("5"));
		System.out.println(d.getReturnDateIO("6"));
	}
}



//Signed by Annafi Anis(23-53083-3)