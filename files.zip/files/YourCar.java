import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class YourCar extends JFrame implements ActionListener
{

   JPanel backPanel, forePanel,forePanel2;
   JLabel imagelabel,l,l1,l5,name1,name2,pnum1,pnum2,email1,email2,nid1,nid2,bdate1,bdate2,rdate1,rdate2;
   JLabel brand1,brand2,model1,model2,regis1,regis2,type1,type2;
   JButton b1,b2,b3;
   ImageIcon img;

public YourCar(){
	//Super("Details");
	this.setSize(900,600);
	this.setLocationRelativeTo(null);
	this.setResizable(false);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	//panel
	backPanel = new JPanel();
	backPanel.setLayout(null);
	backPanel.setBounds(0,0,900,600);
	backPanel.setBackground(Color.white);
	
	
	forePanel =new JPanel();
	forePanel.setLayout(null);
	forePanel.setBounds(40,100,350,400);
	forePanel.setBackground(Color.gray);
	backPanel.add(forePanel);
	
	forePanel2 =new JPanel();
	forePanel2.setLayout(null);
	forePanel2.setBounds(490,100,350,400);
	forePanel2.setBackground(Color.gray);
	backPanel.add(forePanel2);
	
	//labels
	
	l=new JLabel("Transaction Succesfull");
	l.setForeground(Color.gray);
	l.setBounds(250,25,900,35);
	l.setFont(new Font("Arial", Font.BOLD, 32));
	backPanel.add(l);
	
	l1=new JLabel("<HTMl><U>User Details</U></HTMl>");
	l1.setForeground(Color.white);
	l1.setBounds(90,20,900,35);
	l1.setFont(new Font("Arial", Font.BOLD, 28));
	forePanel.add(l1);
	
	name1=new JLabel("Name:");
	name1.setForeground(Color.white);
	name1.setBounds(30,100,150,25);
	name1.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel.add(name1);
	
	pnum1=new JLabel("Phone Number:");
	pnum1.setForeground(Color.white);
	pnum1.setBounds(30,130,130,25);
	pnum1.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel.add(pnum1);
	
	nid1=new JLabel("NID:");
	nid1.setForeground(Color.white);
	nid1.setBounds(30,160,150,25);
	nid1.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel.add(nid1);
	
	email1=new JLabel("Email:");
	email1.setForeground(Color.white);
	email1.setBounds(30,190,150,25);
	email1.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel.add(email1);
	
	bdate1=new JLabel("Booking Date:");
	bdate1.setForeground(Color.white);
	bdate1.setBounds(30,220,150,25);
	bdate1.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel.add(bdate1);
	
	rdate1=new JLabel("Return Date:");
	rdate1.setForeground(Color.white);
	rdate1.setBounds(30,250,150,25);
	rdate1.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel.add(rdate1);
	
	//values
	
	name2=new JLabel(Registrationform.username.getText());
	name2.setForeground(Color.white);
	name2.setBounds(170,100,150,25);
	name2.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel.add(name2);
	
	pnum2=new JLabel(Registrationform.number.getText());
	pnum2.setForeground(Color.white);
	pnum2.setBounds(170,130,150,25);
	pnum2.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel.add(pnum2);
	
	nid2=new JLabel(Registrationform.nid.getText());
	nid2.setForeground(Color.white);
	nid2.setBounds(170,160,150,25);
	nid2.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel.add(nid2);
	
	email2=new JLabel(Registrationform.nid.getText());
	email2.setForeground(Color.white);
	email2.setBounds(170,190,150,25);
	email2.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel.add(email2);
	
	bdate2=new JLabel(Registrationform.CBD.getText());
	bdate2.setForeground(Color.white);
	bdate2.setBounds(170,220,150,25);
	bdate2.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel.add(bdate2);
	
	rdate2=new JLabel(Registrationform.CRD.getText());
	rdate2.setForeground(Color.white);
	rdate2.setBounds(170,250,150,25);
	rdate2.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel.add(rdate2);
	
	l5=new JLabel("Car Details");
	l5.setForeground(Color.white);
	l5.setBounds(100,20,900,35);
	l5.setFont(new Font("Arial", Font.BOLD, 28));
	forePanel2.add(l5);
	
	brand1=new JLabel("Brand:");
	brand1.setForeground(Color.white);
	brand1.setBounds(30,100,150,25);
	brand1.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel2.add(brand1);
	
	model1=new JLabel("Model:");
	model1.setForeground(Color.white);
	model1.setBounds(30,130,150,25);
	model1.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel2.add(model1);
	
	regis1=new JLabel("Registration Num:");
	regis1.setForeground(Color.white);
	regis1.setBounds(30,160,150,25);
	regis1.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel2.add(regis1);
	
	type1=new JLabel("Car Type:");
	type1.setForeground(Color.white);
	type1.setBounds(30,190,150,25);
	type1.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel2.add(type1);
	
	//values
	
	brand2=new JLabel();
	if(SelectCar1.choice==1){brand2.setText("Ford");}
	else if(SelectCar1.choice==2){brand2.setText("Toyota");}
	else if(SelectCar1.choice==3){brand2.setText("Honda");}
	else if(SelectCar1.choice==4){brand2.setText("Subaru");}
	else if(SelectCar1.choice==5){brand2.setText("Volkswagen");}
	else if(SelectCar1.choice==6){brand2.setText("KIA");}	
	brand2.setForeground(Color.white);
	brand2.setBounds(170,100,150,25);
	brand2.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel2.add(brand2);
	
	model2=new JLabel();
	if(SelectCar1.choice==1){model2.setText("Ford Focus");}
	else if(SelectCar1.choice==2){model2.setText("Toyota Corolla");}
	else if(SelectCar1.choice==3){model2.setText("Honda CR-V");}
	else if(SelectCar1.choice==4){model2.setText("Subaru Forester");}
	else if(SelectCar1.choice==5){model2.setText("Volkswagen Atlas");}
	else if(SelectCar1.choice==6){model2.setText("KIA Telluride");}	
	model2.setForeground(Color.white);
	model2.setBounds(170,130,150,25);
	model2.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel2.add(model2);
	
	regis2=new JLabel();
	if(SelectCar1.choice==1){regis2.setText("E022 TCK");}
	else if(SelectCar1.choice==2){regis2.setText("S911 KEK");}
	else if(SelectCar1.choice==3){regis2.setText("S917 IS7");}
	else if(SelectCar1.choice==4){regis2.setText("F083 STR");}
	else if(SelectCar1.choice==5){regis2.setText("V014 SWG");}
	else if(SelectCar1.choice==6){regis2.setText("K181 ASG");}	
	regis2.setForeground(Color.white);
	regis2.setBounds(170,160,150,25);
	regis2.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel2.add(regis2);
	
	type2=new JLabel();
	if(SelectCar1.choice==1){type2.setText("Compact Car");}
	else if(SelectCar1.choice==2){type2.setText("Sedan/Hatchback");}
	else if(SelectCar1.choice==3){type2.setText("Compact SUV");}
	else if(SelectCar1.choice==4){type2.setText("Compact SUV");}
	else if(SelectCar1.choice==5){type2.setText("Meidsize SUV");}
	else if(SelectCar1.choice==6){type2.setText("Meidsize SUV");}	
	type2.setForeground(Color.white);
	type2.setBounds(170,190,150,25);
	type2.setFont(new Font("Arial", Font.BOLD, 16));
	forePanel2.add(type2);
	
	
	
	// l7=new JLabel("Model:");
	// l7.setForeground(Color.white);
	// l7.setBounds(30,150,900,35);
	// l7.setFont(new Font("Arial", Font.BOLD, 24));
	// forePanel2.add(l7);
	
	// l8=new JLabel("Type:");
	// l8.setForeground(Color.white);
	// l8.setBounds(30,210,900,35);
	// l8.setFont(new Font("Arial", Font.BOLD, 24));
	// forePanel2.add(l8);
	
	// l9=new JLabel("Reg no:");
	// l9.setForeground(Color.white);
	// l9.setBounds(30,270,900,35);
	// l9.setFont(new Font("Arial", Font.BOLD, 24));
	// forePanel2.add(l9);
	
	
	backPanel.add(forePanel);
	this.add(backPanel);
	this.setVisible(true);
	
	backPanel.add(forePanel2);
	this.add(backPanel);
	this.setVisible(true);
}
public static void main(String[] args){
		new YourCar();
	}
	public void actionPerformed(ActionEvent ae){
	}
}
	
	