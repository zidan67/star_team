import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SelectCar2 extends JFrame implements ActionListener{
	private static JPanel backPanel, forePanel;
	private static JLabel titleLabel;
	private static JLabel carModelNo1,carModelNo2,carModelNo3;
	private static ImageIcon img1,img2,img3;
	private static Font f1=new Font("Times New Roman", Font.PLAIN, 20);
	private static Font t1=new Font("Times New Roman", Font.BOLD, 28);
	private static JButton c1,c2,c3,back;
	
	
	public SelectCar2(){
		//frame
		this.setTitle("Select your prefered car");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800, 600);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
		
		//backPanel
		backPanel=new JPanel();
        backPanel.setLayout(null);
		backPanel.setBackground(Color.decode("#AFF2DD"));
		
		//forePanel
		forePanel = new JPanel();
        forePanel.setLayout(null);
		forePanel.setBounds(3,3,797,597);
		forePanel.setBackground(Color.decode("#A2A1A1"));
		
		//labels
		titleLabel=new JLabel("SELECT A CAR");
		titleLabel.setForeground(Color.white);
		titleLabel.setBounds(280,30,320,35);
		titleLabel.setFont(t1);
		forePanel.add(titleLabel);
		
		//buttons
		img1=new ImageIcon(getClass().getResource("/bin/images/car4.jpg"));
		c1 = new JButton(img1);
		c1.setBounds(25,100,245,350);
		c1.addActionListener(this);
		forePanel.add(c1);
		
		img2=new ImageIcon(getClass().getResource("/bin/images/car5.jpg"));
		c2 = new JButton(img2);
		c2.setBounds(275,100,245,350);
		c2.addActionListener(this);
		forePanel.add(c2);
		
		img3=new ImageIcon(getClass().getResource("/bin/images/car6.jpg"));
		c3 = new JButton(img3);
		c3.setBounds(525,100,245,350);
		c3.addActionListener(this);
		forePanel.add(c3);
		
		back=new JButton("Back");
		back.setBounds(35,490,100,30);
		back.addActionListener(this);
		forePanel.add(back);
		
		backPanel.add(forePanel);
		this.add(backPanel);
		this.setVisible(true);
	}
	
	
	public void actionPerformed(ActionEvent ae){
		if(ae.getSource()==c1){
			Car4 f=new Car4();
			this.setVisible(false);
		}
		else if(ae.getSource()==c2){
			Car5 f=new Car5();
			this.setVisible(false);
		}
		else if(ae.getSource()==c3){
			Car6 f=new Car6();
			this.setVisible(false);
		}
		else if(ae.getSource()==back){
			SelectCar1 f=new SelectCar1();
			this.setVisible(false);
		}
	}
	public static void main(String[] a){
		new SelectCar2();
	}
}



//Signed by Annafi Anis(23-53083-3)