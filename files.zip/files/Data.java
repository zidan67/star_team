import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public abstract class Data{
	public static String fullName;
	public static String phoneNumber;
	public static String email;
	public static String nid;
	public static String bookingDate;
	public static String returnDate;
    public static File file;
    public static FileWriter writer;
    public static Scanner sc;
	
	//Empty Constructor
    public Data(){
        this.fullName="";
    }
	
	//Para Constructor
	public Data(String fullName, String phoneNumber, String email, String nid, String bookingDate, String returnDate){
		this.fullName=fullName;
		this.phoneNumber=phoneNumber;
		this.email=email;
		this.nid=nid;
		this.bookingDate=bookingDate;
		this.returnDate=returnDate;
	}
	
	public void setFullName(String fullName){this.fullName=fullName;}
	public void setPhoneNumber(String phoneNumber){this.phoneNumber=phoneNumber;}
	public void setEmail(String email){this.email=email;}
	public void setNid(String nid){this.nid=nid;}
	public void setBookingDate(String bookingDate){this.bookingDate=bookingDate;}
	public void setReturnDate(String returnDate){this.returnDate=returnDate;}
	
	public String getFullName(){return this.fullName;}
	public String getPhoneNumber(){return this.phoneNumber;}
	public String getEmail(){return this.email;}
	public String getNid(){return this.nid;}
	public String getBookingDate(){return this.bookingDate;}
	public String getReturnDate(){return this.returnDate;}
	
	
	
	public static void main(String[] agra){
		
	}
}



//Signed by Annafi Anis(23-53083-3)
