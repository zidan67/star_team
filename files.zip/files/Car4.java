import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Car4 extends JFrame implements ActionListener{
	private static JPanel forePanel;
	private static JLabel titleLabel,colon,bName1,bName2,model1,model2,regNo1,regNo2,type1,type2;
	private static JLabel backLabel;
	private static ImageIcon backGround;
	private static Font f1=new Font("Times New Roman", Font.PLAIN, 20);
	private static Font t1=new Font("Times New Roman", Font.BOLD, 28);
	private static JButton back,next;
	
	
	public Car4(){
		//frame
		this.setTitle("Car Details");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800, 600);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
		
		//Background
		backGround=new ImageIcon(getClass().getResource("/bin/images/car4Details.jpg"));
		backLabel=new JLabel(backGround);
		backLabel.setBounds(0,0,800,600);
		
		//data box
		forePanel=new JPanel();
        forePanel.setLayout(null);
		forePanel.setBounds(390,55,380,320);
		forePanel.setBackground(new Color(245,245,245,150));
		forePanel.setBorder(BorderFactory.createLineBorder(new Color(245,245,245,5),10,true));
		
		//labels
		titleLabel=new JLabel("Car Details");
		titleLabel.setBounds(116,20,140,35);
		titleLabel.setFont(t1);
		titleLabel.setBorder(BorderFactory.createMatteBorder(0,0,4,0,new Color(5,5,5,255)));
		forePanel.add(titleLabel);
			
		bName1=new JLabel("Brand");    // brand names
		bName1.setBounds(20,70,150,35);
		bName1.setFont(f1);
		forePanel.add(bName1);
		
		bName2=new JLabel(": Subaru");
		bName2.setBounds(220,70,150,35);
		bName2.setFont(f1);
		forePanel.add(bName2);
			
		model1=new JLabel("Model");     //model
		model1.setBounds(20,120,150,35);
		model1.setFont(f1);
		forePanel.add(model1);
		
		model2=new JLabel(": Subaru Forester");
		model2.setBounds(220,120,150,35);
		model2.setFont(f1);
		forePanel.add(model2);
		
		type1=new JLabel("Car Type");     //car type
		type1.setBounds(20,170,150,35);
		type1.setFont(f1);
		forePanel.add(type1);
		
		type2=new JLabel(": Compact SUV");
		type2.setBounds(220,170,150,35);
		type2.setFont(f1);
		forePanel.add(type2);
		
		regNo1=new JLabel("Registration Number");     //registration number
		regNo1.setBounds(20,220,170,35);
		regNo1.setFont(f1);
		forePanel.add(regNo1);
		
		regNo2=new JLabel(": F083 STR");
		regNo2.setBounds(220,220,150,35);
		regNo2.setFont(f1);
		forePanel.add(regNo2);
		
		//button
		back=new JButton("Back");
		back.setBounds(50,270,70,35);
		back.setFont(new Font("Calibiri", Font.PLAIN, 16));
		back.setBorderPainted(false);
		back.addActionListener(this);
		forePanel.add(back);
		
		next=new JButton("Next");
		next.setBounds(250,270,70,35);
		next.setFont(new Font("Calibiri", Font.PLAIN, 16));
		next.setBorderPainted(false);
		next.addActionListener(this);		
		forePanel.add(next);
		
		backLabel.add(forePanel);
		this.add(backLabel);
		this.setVisible(true);
	}
	
	
	public void actionPerformed(ActionEvent ae){
		if(ae.getSource()==back){
			SelectCar1.choice=0;
			SelectCar2 f=new SelectCar2();
			this.setVisible(false);
		}
		else if(ae.getSource()==next){
			SelectCar1.choice=4;
			Registrationform f=new Registrationform();
			this.setVisible(false);
		}
	}
	public static void main(String[] a){
		new Car4();
	}
}



//Signed by Annafi Anis(23-53083-3)