// PAYMENT OPTION

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class form8 extends JFrame implements ActionListener
{
	JPanel p;
	JLabel l1,l2,l;
	private static JButton l3,l4,l5;
	JButton b1,b2;
	ImageIcon img;
	
	form8()
	{
		super(" Rent Car ");	
		this.setSize(800,600);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		p = new JPanel();
		p.setSize(new Dimension(450,300));
		p.setBackground(Color.gray);
		p.setLayout(null);
		
		img = new ImageIcon(getClass().getResource("carN.jpg"));
		
		l = new JLabel(img);
		l.setBounds(0,7,img.getIconWidth(),550);
		p.add(l);
		
		l1 = new JLabel(" Rent Car ");
		l1.setFont(new Font("Serif",Font.BOLD,40));
		l1.setForeground(new Color(217,249,245));
		l1.setBounds(332,03,445,50);
		l.add(l1);
		
		l2 = new JLabel(" Choose Any Payment Method ");
		l2.setFont(new Font("Serif",Font.BOLD,23));
		l2.setForeground( Color.WHITE );
		l2.setBounds(270,460,350,30);
		l.add(l2); 
		
		l3 = new JButton(" Card ");
		l3.setFont(new Font("Serif",Font.BOLD,21));
		l3.setForeground(new Color(217,249,245));
		l3.setBackground(new Color(0,41,79,255));
		l3.setBorder(BorderFactory.createMatteBorder(1,1,1,1,new Color(217,249,245,255)));
		l3.setBounds(240,506,120,30);
		l3.addActionListener(this);
		l.add(l3); 
		
		l4 = new JButton(" Bkash ");
		l4.setFont(new Font("Serif",Font.BOLD,21));
		l4.setForeground(new Color(217,249,245));
		l4.setBackground(new Color(0,41,79,255));
		l4.setBorder(BorderFactory.createMatteBorder(1,1,1,1,new Color(217,249,245,255)));
		l4.setBounds(375,506,120,30);
		l4.addActionListener(this);
		l.add(l4); 
		
		l5 = new JButton(" Rocket ");
		l5.setFont(new Font("Serif",Font.BOLD,21));
		l5.setForeground(new Color(217,249,245));
		l5.setBackground(new Color(0,41,79,255));
		l5.setBorder(BorderFactory.createMatteBorder(1,1,1,1,new Color(217,249,245,255)));
		l5.setBounds(500,506,120,30);
		l5.addActionListener(this);
		l.add(l5); 
		 
		
		b2 = new JButton("Back");
		b2.setBounds(01,516,100,30);
		b2.setBackground(Color.WHITE);
		b2.addActionListener(this);
		l.add(b2);
		
		this.add(p);
		this.setVisible(true);
		
	}
	

public void actionPerformed(ActionEvent ae)
		{
		    if(ae.getSource()==l3)
			{
				form9 f = new form9();
				this.setVisible(false);
				f.setVisible(true);
			}
			else if(ae.getSource()==l4)
			{
				form10 f = new form10();
				this.setVisible(false);
				f.setVisible(true);
			}
			else if(ae.getSource()==l5)
			{
				form11 f = new form11();
				this.setVisible(false);
				f.setVisible(true);
			}
			else if(ae.getSource()==b2)
			{
				Registrationform f = new Registrationform();
				this.setVisible(false);
			}
		}
		
	public static void main(String[] args){
		new form8();
	}




}